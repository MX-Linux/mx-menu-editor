# Repository Guidelines

## Project Overview
mx-menu-editor is a Qt6 GUI for editing Xfce desktop menu entries: it modifies existing `.desktop` files and creates custom application launchers for MX Linux. The application is read-only/archived since MX Linux moved to menulibre for Xfce and native editors in Plasma.

## Project Structure & Module Organization
- Core Qt sources live in `src/` (`main.cpp`, `mainwindow*`, `addappdialog*`, `desktoputils*`, `docviewer*`) with accompanying `.ui` forms. Resources are bundled via `images.qrc` and icons in `icons/`.
- Localization sources sit in `translations/*.ts` (app) and `translations-desktop-file/*.po`; binary `.qm` files are generated during CMake builds. User-facing help/license HTML lives in `help/`, shown in-app via `docviewer` (no external browser).
- Debian packaging scripts are in `debian/`. The default out-of-source build output goes to `build/` (created by the helper script). The desktop entry is `mx-menu-editor.desktop`.

## Architecture
- **MainWindow** (`src/mainwindow.h/cpp`): primary window and core logic. Manages the tree view of menu categories and applications, loads/parses `.menu` and `.desktop` files, and provides the editing interface for `.desktop` properties. All modifications create/update files in `~/.local/share/applications/`.
- **AddAppDialog** (`src/addappdialog.h/cpp`): dialog for creating new custom application launchers. Generates new `.desktop` files from user input and validates required fields before enabling save.
- **DesktopUtils** (`src/desktoputils.h/cpp`): pure, GUI-free helpers for `.desktop` entry text/metadata (key mutation, localized-name picking, validation). Kept free of `QWidget`/`QObject` so they can be exercised directly by CTest.
- **docviewer** (`src/docviewer.h/cpp`): shows a local HTML document (help, license) in a self-contained `QTextBrowser`/`QDialog` — callers never shell out to an external browser.

### Data flow
1. **Menu loading**: reads Xfce menu files from `/etc/xdg/menus/xfce-applications.menu` and `~/.config/menus/*.menu`.
2. **Parsing**: parses the XML menu structure into a category tree, using `QMultiHash` maps (`hashCategories`, `hashInclude`, `hashExclude`) from menu categories to freedesktop.org categories / explicitly included / excluded files.
3. **Desktop file discovery**: scans `/usr/share/applications/` (system) and `~/.local/share/applications/` (user); local files override system files with the same basename. Uses external `grep`/`find` via `QProcess`.
4. **Editing**: user edits simple form fields (name, command, comment, etc.); changes update a hidden advanced editor (`QTextEdit`) holding the full `.desktop` content. Save writes to `~/.local/share/applications/[filename]` and triggers `xfce4-panel --restart`.

### Key design patterns
- **External process usage**: `QProcess` invokes `grep`/`find` (searching/locating desktop files), `pgrep`/`xfce4-panel` (panel restart), and `gzip -dc` (reading the packaged changelog). Help and license content is rendered in-app via `docviewer`, not an external browser.
- **Override mechanism**: local `.desktop` files in `~/.local/share/applications/` override system files in `/usr/share/applications/`; "Restore App" deletes the local override.
- **Two-level tree**: `QTreeWidget` shows menu categories (bold, dark green) at the top level and applications as children (hidden applications shown in gray).

## File Handling
Standard freedesktop.org `.desktop` entry format:
```
[Desktop Entry]
Name=Application Name
Comment=Description
Exec=/path/to/command
Icon=icon-name
Terminal=true|false
StartupNotify=true|false
NoDisplay=true|false
Type=Application
Categories=Category1;Category2;
```
Boolean fields (`Terminal`, `StartupNotify`, `NoDisplay`, ...) are parsed case-insensitively; valid values are `true`/`false` in any case.

## Build, Test, and Development Commands
- `./build.sh`: Release build with Ninja in `build/`. Use `-d` for Debug, `-c` for clang, `--clean` to reset the build tree.
- Manual CMake: `cmake -B build -GNinja -DCMAKE_BUILD_TYPE=Debug` (add `-DUSE_CLANG=ON` to build with Clang) then `cmake --build build --parallel`. Output binary is `build/mx-menu-editor`.
- Debian package: `./build.sh --debian` produces artifacts under `debs/` and cleans intermediates. Requires Debian tooling (e.g., `debuild`, `dpkg-parsechangelog`).
- Runtime smoke check: launch `./build/mx-menu-editor` after building and verify menu edits apply to `~/.local/share/applications`.
- Build notes: version is parsed from `debian/changelog` via `dpkg-parsechangelog`; MOC/UIC/RCC run automatically; Release builds use LTO.

## Coding Style & Naming Conventions
- C++20 with Qt6. Follow the existing four-space indentation, brace-on-new-line class/function style, and prefer Qt types (`QString`, `QVector`) over STL when interacting with Qt APIs — reach for `std::ranges`/modern STL algorithms for non-Qt-flavored logic (see `desktoputils.cpp`).
- Keep code warning-free under `-Wpedantic -Werror` (default CMake flags). Guard against unused/implicit conversions and return-type issues. Qt 6.0 API level is enforced via `QT_DISABLE_DEPRECATED_BEFORE=0x060000`.
- Prefer `QProcess` over direct system calls for external commands.
- Name classes in UpperCamelCase, member functions in lowerCamelCase, and UI object pointers prefixed by their Qt type conventions (as in existing dialogs). Place new UI text inside `tr()` for translation and add icons from the `:/icons/` resource prefix.

## Testing Guidelines
- `tests/` has a CTest suite (`test_desktoputils`) covering `DesktopUtils` parsing, key mutation, and validation — run via `ctest` from the build directory (or `ctest --test-dir build`). Extend it when adding logic to `desktoputils.cpp`.
- Beyond that, no automated UI test suite is present. Validate UI changes by exercising menu creation, editing, deletion, and category handling, ensuring files land in `~/.local/share/applications` and `~/.local/share/desktop-directories` as expected.
- When touching translations, regenerate `.qm` files via the normal CMake/Ninja build and spot-check language switching if available in your environment.

## Commit & Pull Request Guidelines
- Commit messages are short, imperative summaries (e.g., "Add debug logging", "Fix icon lookup"). Keep one concern per commit when possible.
- Pull requests should describe the change, rationale, and manual test steps. Include screenshots/GIFs for UI-visible adjustments and reference related issues/bugs. Update or add locale strings when text changes, and note any packaging impact (especially when altering `debian/` or `mx-menu-editor.desktop`).
