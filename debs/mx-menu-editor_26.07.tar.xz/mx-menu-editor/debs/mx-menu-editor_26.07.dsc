Format: 3.0 (native)
Source: mx-menu-editor
Binary: mx-menu-editor
Architecture: any
Version: 26.07
Maintainer: Adrian <adrian@mxlinux.org>
Standards-Version: 4.5.1
Vcs-Git: git://github.com/AdrianTM/mx-menu-editor
Build-Depends: debhelper-compat (= 12), cmake (>= 3.16), ninja-build, qt6-base-dev, qt6-base-dev-tools, qt6-tools-dev, qt6-tools-dev-tools
Package-List:
 mx-menu-editor deb admin optional arch=any
Checksums-Sha1:
 172d684c96dd0010a52bf7d1564b5fb1ebe7c43b 241240 mx-menu-editor_26.07.tar.xz
Checksums-Sha256:
 c70cd3941bd3ba8917b97478dee970363bca8c1c9f856f4b3b11db2e1b387684 241240 mx-menu-editor_26.07.tar.xz
Files:
 c6b11a2287571aa41aafccd1ab8529bf 241240 mx-menu-editor_26.07.tar.xz
